package com.example.biblioteca;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.github.barteksc.pdfviewer.PDFView;

public class PdfActivity extends AppCompatActivity {

    PDFView pdfView;
    TextView NomeLivro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf);

        //getSupportActionBar().hide();
        pdfView = findViewById(R.id.pdfView);

        int pos = getIntent().getIntExtra("position", 0);

        if (pos == 0) {
            pdfView.fromAsset("A Sutil Arte de Ligar o Fda-se (Mark Manson) (Z-Library).pdf").load();

        } else if (pos == 1) {
            pdfView.fromAsset("Seja.pdf").load();

        } else if (pos == 2) {
            Toast.makeText(this, "vrch10.pdf", Toast.LENGTH_SHORT).show();
        }
        else if (pos == 3) {
            Toast.makeText(this, "Livro 4", Toast.LENGTH_SHORT).show();
        }

    }
}
