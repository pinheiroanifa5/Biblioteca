package com.example.biblioteca;

public class LivrModel {
    String NomeLivro;

    public LivrModel(String NomeLivro){
        this.NomeLivro=NomeLivro;
    }
    public  String getSetName(){
        return NomeLivro;
    }
    public void setSetName(String setName)    {
        this.NomeLivro=NomeLivro;
    }
}
