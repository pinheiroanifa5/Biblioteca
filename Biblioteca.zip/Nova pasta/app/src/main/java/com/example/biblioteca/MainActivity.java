package com.example.biblioteca;


import com.example.biblioteca.R;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<LivrModel>list;
    LivrAdapter adapter;
    RecyclerView recyclerView;
    NavigationView navigationView;
    DrawerLayout drawerLayout;
    ImageView menu;
    View header;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      //  getSupportActionBar().hide();

        recyclerView=findViewById(R.id.recycleView);

        menu=findViewById(R.id.menu);
        navigationView=(NavigationView)findViewById((R.id.navmenu));
        drawerLayout=(DrawerLayout)findViewById(R.id.drawerLayout);

        list=new ArrayList<>();

        LinearLayoutManager layoutManager =new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        list.add(new LivrModel("Livro 1"));
        list.add(new LivrModel("Livro 2"));
        list.add(new LivrModel("Livro 3"));
        list.add(new LivrModel("Livro 4"));
        list.add(new LivrModel("Livro 5"));
        list.add(new LivrModel("Livro 6"));
        list.add(new LivrModel("Livro 7"));
        list.add(new LivrModel("Livro 8"));
        list.add(new LivrModel("Livro 9"));
        list.add(new LivrModel("Livro 10"));
        adapter=new LivrAdapter(list,this);
        recyclerView.setAdapter(adapter);

        header=navigationView.getHeaderView(0);
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("MenuItem", "menu.setOnClickListener");
                if(drawerLayout.isDrawerOpen(GravityCompat.START)){
                    drawerLayout.closeDrawer(GravityCompat.START);
                }
                else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }

        });

            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        int itemId = item.getItemId();
                    Log.d("MenuItem", String.valueOf(itemId));

                        if (itemId == R.id.home) {
                            Toast.makeText(MainActivity.this, "Home", Toast.LENGTH_SHORT).show();
                            drawerLayout.closeDrawer(GravityCompat.START);
                        } else if (itemId == R.id.share) {
                            Toast.makeText(MainActivity.this, "Share", Toast.LENGTH_SHORT).show();
                            drawerLayout.closeDrawer(GravityCompat.START);
                        } else if (itemId == R.id.favorite) {
                            Toast.makeText(MainActivity.this, "Favoritos", Toast.LENGTH_SHORT).show();
                            drawerLayout.closeDrawer(GravityCompat.START);
                        }

                        return true;
                    }


            });
    }
}